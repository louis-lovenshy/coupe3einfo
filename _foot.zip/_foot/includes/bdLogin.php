<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="foot";

try {
        $conn = new mysqli($servername, $username, $password, $dbname); 
    }
    catch(Exception $e) {
        echo($e->getMessage());
    }

#Check connection
if($conn->connect_error)
{
  die("Connection echoue: " . $conn->connect_error);
}
   // $db = mysqli_connect($db_host, $db_username, $db_password,$db_name) or die('Connexion impossible');
?> 
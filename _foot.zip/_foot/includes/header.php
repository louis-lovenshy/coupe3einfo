<?php
	
	if(isset($_SESSION['uname'])){

  ?>


<header class="header">

		<div class="logoContainer">

			<h1 class="logo">Coupe</h1>

		</div>
		<script type="text/javascript" src="./js/index.js" ></script>
		
		<div class="menu">
			<img src="./icon/menu.png" class="menuImg" onclick="show_hide();">
		</div>

		<!-- navBar -->

		<nav class="navBar" id="nav">
			<a href="./index.php" class="link">Accueil</a>
			<a href="./classement.php" class="link">Classement</a>
			<a href="./stats.php" class="link">Statistiques</a>
			
		</nav>
		<div class="logout">
		<a href="./action/logout.php"><button>Log out</button></a>
		</div>
		
	</header>

<?php
	}else{
		header('Location:./login.php');
	}



?>
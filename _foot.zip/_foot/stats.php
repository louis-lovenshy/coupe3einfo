<?php
 	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Coupe 3eme Infos | Statistiques</title>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="./css/index.css">
</head>
<body>
	<?php
		require './includes/header.php';
		require './includes/bdLogin.php';

		$nbTb = 0; 
		$nbmj = 0;
		$moyenne = 0;
		$sql = "SELECT SUM(SCORE1 + SCORE2) nb FROM matchs";
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) > 0){
			$row = mysqli_fetch_array($result);
			$nbTb = $row['nb'];
		}
		$sql = "SELECT COUNT(id) nb FROM matchs";
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) > 0){
			$row = mysqli_fetch_array($result);
			$nbmj = $row['nb'];
		}
		
		
		$sql = "SELECT avg(score1+score2) moy from matchs";
		$result = mysqli_query($conn, $sql);
		if(mysqli_num_rows($result) > 0){
			$row = mysqli_fetch_array($result);
			$moyenne = $row['moy'];
		}		
	?>

	<div style="text-align: center;">

	<h1 class="h1 h1-center">Statistiques</h1>
	<div>Nombre de matchs joue: <span><?=$nbmj;?></span></div>
	<div>Nombre total de buts: <span><?=$nbTb;?></span></div>
	<div>Moyenne de buts par match: <span><?=$moyenne;?></span></div>
	<!-- <div>Equipe ayant le plus de matchs gagnes pendant le premier tour: <span></span></div>
	<div>Equipe ayant le plus de buts marque:</div>
	<div>Equipe ayant le plus de buts pris:</div> -->
	</div>


</body>
</html>


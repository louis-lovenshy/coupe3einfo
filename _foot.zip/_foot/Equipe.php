<?php

class Equipe {

    private $nom;
    private $mj;
    private $mg;
    private $mn;
    private $mp;
    private $bp;
    private $bc;
    private $dif;
    private $point;

    function __construct($nom, $mj, $mg, $mn, $mp, $bp, $bc, $dif, $point) {
        $this->nom = $nom;
        $this->mj = $mj;
        $this->mg = $mg;
        $this->mn = $mn;
        $this->mp = $mp;
        $this->bp = $bp;
        $this->bc = $bc;
        $this->dif = $dif;
        $this->point = $point;
    }

    function getNom() {
        return $this->nom;
    }

    function getMj() {
        return $this->mj;
    }

    function getMg() {
        return $this->mg;
    }

    function getMn() {
        return $this->mn;
    }

    function getMp() {
        return $this->mp;
    }

    function getBp() {
        return $this->bp;
    }

    function getBc() {
        return $this->bc;
    }

    function getDif() {
        return $this->dif;
    }

    function getPoint() {
        return $this->point;
    }

    function setNom($nom) {
        $this->nom = $nom;
    }

    function setMj($mj) {
        $this->mj = $mj;
    }

    function setMg($mg) {
        $this->mg = $mg;
    }

    function setMn($mn) {
        $this->mn = $mn;
    }

    function setMp($mp) {
        $this->mp = $mp;
    }

    function setBp($bp) {
        $this->bp = $bp;
    }

    function setBc($bc) {
        $this->bc = $bc;
    }

    function setDif($dif) {
        $this->dif = $dif;
    }

    function setPoint($point) {
        $this->point = $point;
    }

    

}

?>
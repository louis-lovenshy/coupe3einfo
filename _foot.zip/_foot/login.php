<?php
	session_start();
	if (isset($_SESSION['error']) && !empty($_SESSION['error'])) {
		echo "<div class='error-message'>".$_SESSION['error']."</div>";
		$_SESSION['error'] = "";
	}

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login | </title>
	<link rel="stylesheet" type="text/css" href="./css/login.css">
</head>
<body>

	<div class="login">
            <div class="login-screen">
                <div class="app-title">
                    <h1>Login</h1>
                </div>

	<form method="post" action="./action/signin_process.php" class="form" autocomplete="off">
		<form class="login-form" method="post" action="./actions/signin_process.php" autocomplete="off">
                    <div class="control-group">
                        <input type="text" name="uname" placeholder="username" required class="input">
                    </div>

                    <div class="control-group">
                        <input type="password" name="passwd" placeholder="password" required class="input" id="pass">
                    </div>

                    <button type="submit" class="btn" name="connect">Connect</button>
                    <div><a href="./action/signin.php" class="signinlink">create new account</a></div>

                </form>
            </div>
        </div>

</body>
</html>
function show_hide() {
	let x = document.getElementById('nav');


	if (x.className=='navBar'){
		x.className='mobile-navBar';
	}
	else{
		x.className='navBar';
	}
}


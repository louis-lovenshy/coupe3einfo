<?php
	include './Equipe.php';
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Coupe 3e Infos | Home</title>
	<link rel="stylesheet" type="text/css" href="./css/index.css">
	<link rel="stylesheet" type="text/css" href="./css/index_home.css">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
	<?php 
		require './includes/header.php';
		require './includes/bdLogin.php';
	 ?>
	<?php 

		
		// declaration des differents lots d'equipes dans des tableaux
		$lot1 = ['Brésil','Argentine'];
		$lot2 = ['France','Italie'];
		$lot3 = ['Espagne','Allemagne'];
		$lot4 = ['Portugal','Haïti'];

		function getMatchScore1($id){
			global $conn;
			$score = "";
			$sql = "SELECT score1 FROM matchs WHERE id = $id";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				$row = mysqli_fetch_array($result);
				$score = $row['score1'];
			}
			return $score;
			mysqli_free_result($result);
		}

		function getMatchScore2($id){
			global $conn;
			$score = "";
			$sql = "SELECT score2 FROM matchs WHERE id = $id";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				$row = mysqli_fetch_array($result);
				$score = $row['score2'];
			}
			return $score;
			mysqli_free_result($result);
		}

		function getSFinaliste1($id){
			global $conn;
			$equipe = "";
			$sql = "select equipe from classementa WHERE mj = 3 and id = $id";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				$row = mysqli_fetch_array($result);
				$equipe = $row['equipe'];
			}
			return $equipe;
		}

		function getSFinaliste2($id){
			global $conn;
			$equipe = "";
			$sql = "select equipe from classementb WHERE mj = 3 and id = $id";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				$row = mysqli_fetch_array($result);
				$equipe = $row['equipe'];
			}
			return $equipe;
		}

		


		

		if (isset($_SESSION['groupeA']) && isset($_SESSION['groupeB']) ) {
			global $noTirage, $groupeA, $groupeB;			 
			$noTirage = 1;
			$sql = "select equipe from groupea";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				$i = 0;
				while ($row = mysqli_fetch_array($result)) {
					$groupeA[$i++] = $row['equipe'];
				}
			}

			$sql = "select equipe from groupeb";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				$i = 0;
				while ($row = mysqli_fetch_array($result)) {
					$groupeB[$i++] = $row['equipe'];
				}
			}
			// for ($i=0; $i < 4; $i++) { 
			// 	$groupeA[$i] = $_SESSION['groupeA'][$i]->getNom(); # regroupement des noms des equipes du groupe A dans un tableau

			// 	$groupeB[$i] = $_SESSION['groupeB'][$i]->getNom(); # regroupement des noms des equipes du groupe B dans un tableau
			// }

		}
		else{
			$noTirage = 0;
		}
		

		
	 ?>

	<main class="main-index">
		
			<table class="table">
			<caption class="caption">Liste des equipes</caption>
			<tbody>
				<tr class="tr">
					<th class="th">Lot # 1 (1e tête de série)</th>
					<th class="th">Lot # 2 (2e tête de série)</th>
					<th class="th">Lot # 3 (3e tête de série)</th>
					<th class="th">Lot # 4 (4e tête de série)</th>
				</tr>

				<tr class="tr">
					<td class="td"><?php echo($lot1[0]); ?></td>
					<td class="td"><?php echo($lot2[0]); ?></td>
					<td class="td"><?php echo($lot3[0]); ?></td>
					<td class="td"><?php echo($lot4[0]); ?></td>				
				</tr>

				<tr class="tr">
					<td class="td"><?php echo($lot1[1]); ?></td>
					<td class="td"><?php echo($lot2[1]); ?></td>
					<td class="td"><?php echo($lot3[1]); ?></td>
					<td class="td"><?php echo($lot4[1]); ?></td>				
				</tr>
				
			</tbody>
		</table>

		<a href="./action/tirage.php"><button id="tirage-button" type="submit" >Tirage</button></a>
		
	
		<?php  if ($noTirage == 1) { # s'il n'y pas de tirage, on ne peut pas afficher de groupe
			// if (isset($groupeA) && !empty($groupeB[0])) {
			
			
		 ?>
		<table class="table">
			<tbody>
				<tr class="tr">
					<th class="th">Groupe A</th>
					<th class="th">Groupe B</th>
				</tr>
				<?php 
					for ($i=0; $i < 4; $i++) { 
					  
						echo"<tr class='tr'>";
							echo('<td class="td">'.$groupeA[$i].'</td>');
							echo('<td class="td">'.$groupeB[$i].'</td>');									
						echo"</tr>";
					}
				?>
				

				
				
			</tbody>
		</table><br>
		<!-- <form action="./classement.php"> -->
		<table class="table">
			<tbody>
				<tr class="tr">
					<th class="th">Groupe A</th>
					<th class="th">Affiche</th>
					<th class="th">Score</th>
				</tr>

				<tr class="tr">
					<td class="td">Match 1</td>
					<td class="td"><?php echo($groupeA[0]." VS ".$groupeA[1]); ?></td>
					<td>
						<input type="number" name="<?php echo $groupeA[0] ?>" value="<?=getMatchScore1(1); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeA[1] ?>" value="<?=getMatchScore2(1); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="1">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 2</td>
					<td class="td"><?php echo($groupeA[2]." VS ".$groupeA[3]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeA[2] ?>" value="<?=getMatchScore1(2); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeA[3] ?>" value="<?=getMatchScore2(2); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="2">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 3</td>
					<td class="td"><?php echo($groupeA[0]." VS ".$groupeA[2]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeA[0] ?>" value="<?=getMatchScore1(3); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeA[2] ?>" value="<?=getMatchScore2(3); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="3">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 4</td>
					<td class="td"><?php echo($groupeA[1]." VS ".$groupeA[3]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeA[1] ?>" value="<?=getMatchScore1(4); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeA[3] ?>" value="<?=getMatchScore2(4); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="4">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 5</td>
					<td class="td"><?php echo($groupeA[0]." VS ".$groupeA[3]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeA[0] ?>" class="input" value="<?=getMatchScore1(5); ?>" onchange="updateTeam1(this);" >
						-
						<input type="number" name="<?php echo $groupeA[3] ?>" class="input" value="<?=getMatchScore2(5); ?>" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="5">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 6</td>
					<td class="td"><?php echo($groupeA[1]." VS ".$groupeA[2]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeA[1] ?>" value="<?=getMatchScore1(6); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeA[2] ?>" value="<?=getMatchScore2(6); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="6">Save</button>
					</td>									
				</tr>
				
			</tbody>
			
		</table><br>

		<table class="table">
			<tbody>
				<tr class="tr">
					<th class="th">Groupe B</th>
					<th class="th">Affiche</th>
					<th class="th">Score</th>
				</tr>

				<tr class="tr">
					<td class="td">Match 1</td>
					<td class="td"><?php echo($groupeB[0]." VS ".$groupeB[1]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeB[0] ?>" value="<?=getMatchScore1(7); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeB[1] ?>" value="<?=getMatchScore2(7); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="7">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 2</td>
					<td class="td"><?php echo($groupeB[2]." VS ".$groupeB[3]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeB[2] ?>" value="<?=getMatchScore1(8); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeB[3] ?>" value="<?=getMatchScore2(8); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="8">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 3</td>
					<td class="td">
						<?php echo($groupeB[0]." VS ".$groupeB[2]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeB[0] ?>" value="<?=getMatchScore1(9); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeB[2] ?>" value="<?=getMatchScore2(9); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="9">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 4</td>
					<td class="td"><?php echo($groupeB[1]." VS ".$groupeB[3]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeB[1] ?>" value="<?=getMatchScore1(10); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeB[3] ?>" value="<?=getMatchScore2(10); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="10">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 5</td>
					<td class="td"><?php echo($groupeB[0]." VS ".$groupeB[3]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeB[0] ?>" value="<?=getMatchScore1(11); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeB[3] ?>" value="<?=getMatchScore2(11); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="11">Save</button>
					</td>									
				</tr>

				<tr class="tr">
					<td class="td">Match 6</td>
					<td class="td"><?php echo($groupeB[1]." VS ".$groupeB[2]); ?></td>
					<td class="td">
						<input type="number" name="<?php echo $groupeB[1] ?>" value="<?=getMatchScore1(12); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?php echo $groupeB[2] ?>" value="<?=getMatchScore2(12); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="12">Save</button>
					</td>									
				</tr>
				
			</tbody>
			
		</table><br>

		<?php
			if (isset($_SESSION['groupeA']) && isset($_SESSION['groupeA'])) {
			 	if ($_SESSION['groupeA'][0]->getMj() == 3) {
			 		if ($_SESSION['groupeA'][1]->getMj() == 3) {
			 			if ($_SESSION['groupeA'][2]->getMj() == 3) { 
			 				if ($_SESSION['groupeA'][3]->getMj() == 3) {
			 					if ($_SESSION['groupeB'][0]->getMj() == 3) {
			 						if ($_SESSION['groupeB'][1]->getMj() == 3) {
			 							if ($_SESSION['groupeB'][2]->getMj() == 3) {
			 								if ($_SESSION['groupeB'][3]->getMj() == 3) {
			 		
			 	
			
		?>

		<table class="table">
			<h1 class="h1 h1-center">Demi-Finale</h1>
			<tbody>
				<tr class="tr">
					<th class="th">Match</th>
					<th class="th">Affiche</th>
					<th class="th">Score</th>
				</tr>

				<tr class="tr">
					<td class="td">Match 1</td>
					<td class="td"><?php echo(getSFinaliste1(1)." VS ".getSFinaliste2(2)); ?></td>
					<td class="td">
						<input type="number" name="<?=getSFinaliste1(1); ?>" value="<?=getMatchScore1(13); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?=getSFinaliste2(2); ?>" value="<?=getMatchScore2(13); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="13">Save</button>
					</td>
				</tr>

				<tr class="tr">
					<td class="td">Match 2</td>
					<td class="td"><?php echo(getSFinaliste2(1)." VS ".getSFinaliste1(2)); ?></td>
					<td class="td">
						<input type="number" name="<?=getSFinaliste2(1); ?>" value="<?=getMatchScore1(14); ?>" class="input" onchange="updateTeam1(this);">
						-
						<input type="number" name="<?=getSFinaliste1(2); ?>" value="<?=getMatchScore2(14); ?>" class="input" onchange="updateTeam2(this);">
						<button class="save_button" onclick="addScore(this.id);" id="14">Save</button>
					</td>
				</tr>
			</tbody>
		</table>

		<?php  } } } } } } } } }  ?>

		<?php
			$sql = "SELECT equipe from pfinal";
			$result = mysqli_query($conn, $sql);
			$pfinal;
			if(mysqli_num_rows($result) > 1){
				$i = 0;
				while($row = mysqli_fetch_array($result)){ 
					$pfinal[$i] = $row['equipe'];
					$i += 1;
				}?>

				<table class="table">
					<h1 class="h1 h1-center">Petite Finale</h1>
					<tbody>
						<tr class="tr">
							<th class="th">Match</th>
							<th class="th">Affiche</th>
							<th class="th">Score</th>
						</tr>

						<tr class="tr">
							<td class="td">Match 1</td>
							<td class="td"><?php echo($pfinal[0]." 
							VS 
							".$pfinal[1]); ?></td>

							<td class="td">
					<input type="number" name="<?=$pfinal[0]; ?>" value="<?=getMatchScore1(15); ?>" class="input" onchange="updateTeam1(this);">
					-
					<input type="number" name="<?=$pfinal[1]; ?>" value="<?=getMatchScore2(15); ?>" class="input" onchange="updateTeam2(this);">
					<button class="save_button" onclick="addScore(this.id);" id="15">Save</button>
				</td>
						</tr>
						
					</tbody>
				</table>


		<?php
			if(isset($_SESSION['rpf'])){
				echo "<h1 class='h1-center'>".$_SESSION['rpf']."</h1>";
			}
		 } ?>

		<?php
		$sql = "SELECT equipe from finaliste";
			$result = mysqli_query($conn, $sql);
			$final;
			if(mysqli_num_rows($result) > 1){
				$i = 0;
				while($row = mysqli_fetch_array($result)){ 
					$final[$i++] = $row['equipe'];
				}?>

				<table class="table">
					<h1 class="h1 h1-center">Finale</h1>
					<tbody>
						<tr class="tr">
							<th class="th">Match</th>
							<th class="th">Affiche</th>
							<th class="th">Score</th>
						</tr>

						<tr class="tr">
							<td class="td">Match 1</td>
							<td class="td"><?php echo($final[0]." VS ".$final[1]); ?></td>

							<td class="td">
					<input type="number" name="<?=$final[0]; ?>" value="<?=getMatchScore1(16); ?>" class="input" onchange="updateTeam1(this);">
					-
					<input type="number" name="<?=$final[1]; ?>" value="<?=getMatchScore2(16); ?>" class="input" onchange="updateTeam2(this);">
					<button class="save_button" onclick="addScore(this.id);" id="16">Save</button>
				</td>
						</tr>
						
					</tbody>
				</table>
		<?php
			if(isset($_SESSION['rf'])){ ?>
				<img src="./img/cup.png" class="cup">
				<?php
				echo "<h1 class='h1-center'>".$_SESSION['rf']."</h1>";
			}
		 } ?>


		<?php } ?>



	</main>

	<script type="text/javascript">
		var nameTeam1 = '';
		var valueTeam1 = '';
		var nameTeam2 = '';
		var valueTeam2 = '';
		function updateTeam1(n) {	
			nameTeam1 = n.name;
			valueTeam1 = n.value;	
		}
		function updateTeam2(n) {
			nameTeam2 = n.name;
			valueTeam2 = n.value;	
		}

		function addScore(id) {
			if (nameTeam1==='' || nameTeam2==='' || valueTeam1==='' || valueTeam1==='') {
				alert("veuillez remplir tous les champs");
			}else{
				window.location.href = "./action/traitement.php?eq1="+nameTeam1+"&sc1="+valueTeam1+
				"&eq2="+nameTeam2+"&sc2="+valueTeam2+'&idMatch='+id;
			}
			

		}
		
		
		<?php 
		// if (isset($_SESSION['disabled']) && count($_SESSION['disabled']) > 0) {
			$sql = "SELECT id FROM matchs";
			$result = mysqli_query($conn, $sql);
			if(mysqli_num_rows($result) > 0){
				while($row = mysqli_fetch_array($result)){ ?>
			 	
			 	document.getElementById(<?php echo($row['id']); ?>).disabled = true;
			<?php } } ?>
		 
		

	</script>

</body>
</html>
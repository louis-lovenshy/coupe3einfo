<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Coupe 3e Infos | Classement</title>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="./css/index.css">
	<link rel="stylesheet" type="text/css" href="./css/classement.css">
</head>
<body>
	<?php 
		include './Equipe.php';
		SESSION_start();		
 		require './includes/header.php';
 		require './includes/bdLogin.php';
		
		$sql = "SELECT * FROM classementa";
        if($result = mysqli_query($conn, $sql))
        {
          	if(mysqli_num_rows($result) > 0)
          	{
            	

	 ?>
	 <table class="table">
	 	<caption class="caption">Groupe A</caption>
	 	<tbody>
	 		<tr class="tr">
				<th class="th">Equipe</th>
				<th class="th">MJ</th>
				<th class="th">MG</th>
				<th class="th">MN</th>
				<th class="th">MP</th>
				<th class="th">BP</th>
				<th class="th">BC</th>
				<th class="th">DIF</th>
				<th class="th">POINT</th>
			</tr>
                        
            
            
            <?php 
            while($row = mysqli_fetch_array($result))
            	{
                	echo "<tr class='tr'>";
	                echo('<td class="td">'.$row['equipe'].'</td>');
	                echo('<td class="td">'.$row['mj']    .'</td>');
                    echo('<td class="td">'.$row['mg']    .'</td>');
                    echo('<td class="td">'.$row['mn']    .'</td>');
                    echo('<td class="td">'.$row['mp']    .'</td>');
                    echo('<td class="td">'.$row['bp']    .'</td>');
                    echo('<td class="td">'.$row['bc']    .'</td>');
                    echo('<td class="td">'.$row['diff']   .'</td>');
                    echo('<td class="td">'.$row['pt']   .'</td>');
                    echo "</tr>";
	            }
	        ?> 
            
	 		
	 	</tbody>
	 	
	 </table>
	<?php }} 

	 $sql = "SELECT * FROM classementb";
        if($result = mysqli_query($conn, $sql))
        {
          	if(mysqli_num_rows($result) > 0)
          	{
            	

	 ?>
	 <table class="table">
	 	<caption class="caption">Groupe B</caption>
	 	<tbody>
	 		<tr class="tr">
				<th class="th">Equipe</th>
				<th class="th">MJ</th>
				<th class="th">MG</th>
				<th class="th">MN</th>
				<th class="th">MP</th>
				<th class="th">BP</th>
				<th class="th">BC</th>
				<th class="th">DIF</th>
				<th class="th">POINT</th>
			</tr>
                        
            
            
            <?php 
            while($row = mysqli_fetch_array($result))
            	{
                	echo "<tr class='tr'>";
	                echo('<td class="td">'.$row['equipe'].'</td>');
	                echo('<td class="td">'.$row['mj']    .'</td>');
                    echo('<td class="td">'.$row['mg']    .'</td>');
                    echo('<td class="td">'.$row['mn']    .'</td>');
                    echo('<td class="td">'.$row['mp']    .'</td>');
                    echo('<td class="td">'.$row['bp']    .'</td>');
                    echo('<td class="td">'.$row['bc']    .'</td>');
                    echo('<td class="td">'.$row['diff']   .'</td>');
                    echo('<td class="td">'.$row['pt']   .'</td>');
                    echo "</tr>";
	            }
	        ?> 
            
	 		
	 	</tbody>
	 	
	 </table>
	<?php }} ?>

</body>
</html>
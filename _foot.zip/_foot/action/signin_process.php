<?php

session_start();
require ".././includes/bdLogin.php";
// global $success;
    $success = 0;
    print_r($_POST);
    $user = SecurisationDonnees($_POST['uname']);
    $pass = SecurisationDonnees($_POST['passwd']);
    


if (isset($_POST['signin']) && !empty($_POST['uname']) && !empty($_POST['passwd']) && !empty($_POST['passwdC'])) {

    
    $sql = "INSERT INTO user VALUES (null,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $user, $pass);  

    $pass2 = SecurisationDonnees($_POST['passwdC']);  

    if ($pass === $pass2) {
        $k = $stmt->execute();
        $conn->close();
        if ($k) {
            echo("ok");
            $_SESSION['signin-error'] = "Sign in with success";
            $success = 1;
        } else {
            $_SESSION['signin-error'] = "Username already taken";
        }
    } else {
        $_SESSION['signin-error'] = "passwords are diferrent";
    }
}elseif(isset($_POST['connect']) && !empty($_POST['uname']) && !empty($_POST['passwd']) ) {
	$sql = "SELECT * FROM user WHERE username ='$user' and password= '$pass'";
	$result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION['uname'] = $row['username'];
            $success = -1;
        }
        $conn->close();
	}else {
        $_SESSION['error'] = "Compte Inexistant";
        $success = -1;
    }
}

if ($success == 1 || $success == -1) {
    header('Location:.././index.php');
}elseif($success == -2){
	header('Location:.././login.php');
} else {
    header('Location:./signin.php');
}

function SecurisationDonnees($donnee) {
    $donnee = htmlspecialchars($donnee);
    $donnee = trim($donnee);
    $donnee = stripslashes($donnee);
    return $donnee;
}

?>
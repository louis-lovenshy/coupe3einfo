<?php
	include '../Equipe.php';
	require_once '.././includes/bdLogin.php';
	session_start();
	$equipe1 =$_GET['eq1'];
	$equipe2 =$_GET['eq2'];
	$id = $_GET['idMatch'];
	// array_push($_SESSION['disabled'], $id);
	// print_r($_SESSION['disabled']);
	// var_dump($id);

	// echo($equipe1."-".$equipe2."<br>");

	$score1 = $_GET['sc1'];
	$score2 = $_GET['sc2'];

	$insertion = "INSERT INTO matchs VALUES ($id, '$equipe1', $score1, '$equipe2', $score2)";
	mysqli_query($conn, $insertion);


if($id < 13){
			

	$sql = "SELECT * FROM classementa";
    if($result = mysqli_query($conn, $sql))
    {
        if(mysqli_num_rows($result) > 0) 
        {
            $i = 0;
            while($row = mysqli_fetch_array($result)) 
            {
              	$_SESSION['groupeA'][$i++] = new Equipe($row['equipe'],$row['mj'],$row['mg'],$row['mn'],$row['mp'],$row['bp'],$row['bc'],$row['diff'],$row['pt']);     
        	}
            // Free result set
            mysqli_free_result($result);
        }
    }

    $sql = "SELECT * FROM classementb";
    if($result = mysqli_query($conn, $sql))
    {
        if(mysqli_num_rows($result) > 0) 
        {
            $i = 0;
            while($row = mysqli_fetch_array($result)) 
            {
              	$_SESSION['groupeB'][$i++] = new Equipe($row['equipe'],$row['mj'],$row['mg'],$row['mn'],$row['mp'],$row['bp'],$row['bc'],$row['diff'],$row['pt']);     
        	}
            // Free result set
            mysqli_free_result($result);
        }
    }

	

	for ($i=0; $i < 4; $i++) { 
		if($_SESSION['groupeA'][$i]->getNom() === $equipe1){
			$indexEquipe1 = 'groupeA';
			$posEquipe1 = $i;
		}

		if ($_SESSION['groupeA'][$i]->getNom() === $equipe2) {
				$indexEquipe2 = 'groupeA';
				$posEquipe2 = $i;
		}

		if($_SESSION['groupeB'][$i]->getNom() === $equipe2){
			$indexEquipe2 = 'groupeB';
			$posEquipe2 = $i;
		}
		
		if ($_SESSION['groupeB'][$i]->getNom() === $equipe1) {
			$indexEquipe1 = 'groupeB';
			$posEquipe1 = $i;			
		}
	}
	$eq1 = $_SESSION[$indexEquipe1][$posEquipe1];
	$eq2 = $_SESSION[$indexEquipe2][$posEquipe2];

	// print_r($eq1);

	if ($score1 > $score2) {
		// on incremente les matchs joues
		$eq1->setMj($eq1->getMj()+1);
		$eq2->setMj($eq2->getMj()+1);

		// on incremente les gains et les defaites
		$eq1->setMg($eq1->getMg()+1);
		$eq2->setMp($eq2->getMp()+1);

		// on actualise les buts marques
		$eq1->setBp($eq1->getBp()+$score1);
		$eq2->setBp($eq2->getBp()+$score2);

		// on actualise les buts pris
		$eq1->setBc($eq1->getBc()+$score2);
		$eq2->setBc($eq2->getBc()+$score1);

		// on actualise la difference de buts
		$eq1->setDif($eq1->getBp() - $eq1->getBc());
		$eq2->setDif($eq2->getBp() - $eq2->getBc());

		// on actualise les points
		$eq1->setPoint($eq1->getPoint()+3);

	}

	else
		if ($score1 < $score2) {
		// on incremente les matchs joues
		$eq1->setMj($eq1->getMj()+1);
		$eq2->setMj($eq2->getMj()+1);

		// on incremente les gains et les defaites		
		$eq2->setMg($eq2->getMg()+1);
		$eq1->setMp($eq1->getMp()+1);

		// on actualise les buts marques
		$eq1->setBp($eq1->getBp()+$score1);
		$eq2->setBp($eq2->getBp()+$score2);

		// on actualise les buts pris
		$eq1->setBc($eq1->getBc()+$score2);
		$eq2->setBc($eq2->getBc()+$score1);

		// on actualise la difference de buts
		$eq1->setDif($eq1->getBp() - $eq1->getBc());
		$eq2->setDif($eq2->getBp() - $eq2->getBc());

		// on actualise les points
		$eq2->setPoint($eq2->getPoint()+3);

	}
	else{
		// on incremente les matchs joues
		$eq1->setMj($eq1->getMj()+1);
		$eq2->setMj($eq2->getMj()+1);

		// on incremente les gains et les defaites et les nuls		
		$eq2->setMn($eq2->getMn()+1);
		$eq1->setMn($eq1->getMn()+1);

		// on actualise les buts marques
		$eq1->setBp($eq1->getBp()+$score1);
		$eq2->setBp($eq2->getBp()+$score2);

		// on actualise les buts pris
		$eq1->setBc($eq1->getBc()+$score2);
		$eq2->setBc($eq2->getBc()+$score1);

		// on actualise la difference de buts
		$eq1->setDif($eq1->getBp() - $eq1->getBc());
		$eq2->setDif($eq2->getBp() - $eq2->getBc());

		// on actualise les points
		$eq1->setPoint($eq1->getPoint()+1);
		$eq2->setPoint($eq2->getPoint()+1);
	}

	

	usort($_SESSION['groupeA'], 'comparator');
	usort($_SESSION['groupeB'], 'comparator');

	$sql = "truncate classementa;";
    mysqli_query($conn, $sql);


    $sql = "truncate classementb;";
    mysqli_query($conn, $sql);
    


    for ($i=0; $i <4 ; $i++) 
    { 
    	$nom[$i] = $_SESSION['groupeA'][$i]->getNom();
        $mj[$i] = $_SESSION['groupeA'][$i]->getMj();
        $mg[$i] = $_SESSION['groupeA'][$i]->getMg();
        $mn[$i] = $_SESSION['groupeA'][$i]->getMn();
        $mp[$i] = $_SESSION['groupeA'][$i]->getMp();
        $bp[$i] = $_SESSION['groupeA'][$i]->getBp();
        $bc[$i] = $_SESSION['groupeA'][$i]->getBc();
        $diff[$i] = $_SESSION['groupeA'][$i]->getDif();
        $pt[$i] = $_SESSION['groupeA'][$i]->getPoint();
    	$insert = "INSERT INTO classementa VALUES (null, '$nom[$i]', '$mj[$i]', '$mg[$i]', '$mn[$i]', '$mp[$i]', '$bp[$i]', '$bc[$i]', '$diff[$i]', '$pt[$i]')";
		mysqli_query($conn, $insert);
    }

    for ($i=0; $i <4 ; $i++){
    	$nom[$i] = $_SESSION['groupeB'][$i]->getNom();
        $mj[$i] = $_SESSION['groupeB'][$i]->getMj();
        $mg[$i] = $_SESSION['groupeB'][$i]->getMg();
        $mn[$i] = $_SESSION['groupeB'][$i]->getMn();
        $mp[$i] = $_SESSION['groupeB'][$i]->getMp();
        $bp[$i] = $_SESSION['groupeB'][$i]->getBp();
        $bc[$i] = $_SESSION['groupeB'][$i]->getBc();
        $diff[$i] = $_SESSION['groupeB'][$i]->getDif();
        $pt[$i] = $_SESSION['groupeB'][$i]->getPoint();
    	$insert = "INSERT INTO classementb VALUES (null, '$nom[$i]', '$mj[$i]', '$mg[$i]', '$mn[$i]', '$mp[$i]', '$bp[$i]', '$bc[$i]', '$diff[$i]', '$pt[$i]')";
		mysqli_query($conn, $insert);
    }

}
else if($id >=13 && $id <= 14){

		if ($score1 > $score2) {
			$sql = "INSERT INTO finaliste values(null, '$equipe1')";
			mysqli_query($conn, $sql);
			$sql = "INSERT INTO pfinal  values(null, '$equipe2')";
			mysqli_query($conn, $sql);
			echo "a sup";
		}else if($score1 == $score2){
			$sql = "INSERT INTO finaliste values(null, '$equipe1')";
			mysqli_query($conn, $sql);
			$sql = "INSERT INTO pfinal  values(null, '$equipe2')";
			mysqli_query($conn, $sql);
			echo "eq";
			
		}else{
			$sql = "INSERT INTO finaliste values(null, '$equipe2')";
			mysqli_query($conn, $sql);
			$sql = "INSERT INTO pfinal  values(null, '$equipe1')";
			echo "b sup";
			mysqli_query($conn, $sql);
		}
	}
else if($id == 15){
	global $pwinner;
	if ($score1 > $score2){
		$_SESSION['rpf'] = $equipe1." remporte la petite finale";
	}else if($score1 == $score2){
		$_SESSION['rpf'] = $equipe1." remporte la petite finale";
	}else{
		$_SESSION['rpf'] = $equipe2." remporte la petite finale";
	}
}else{
	if ($score1 > $score2){
		$_SESSION['rf'] = $equipe1." remporte la finale";
	}else if($score1 == $score2){
		$_SESSION['rf'] = $equipe1." remporte la finale";
	}else{
		$_SESSION['rf'] = $equipe2." remporte la finale";
	}
}
		

	
function comparator($equipe1,$equipe2) {
		return $equipe2->getPoint() > $equipe1->getPoint();
	}
	

	header('location:.././index.php');


?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>

</body>
</html>


<?php
	
	
	require_once '../Equipe.php'; // inclusuin de la classe equipe
	require_once '../includes/bdLogin.php';
 	session_start(); // demarrage d'une session
	$_SESSION['disabled'] = []; #pour desativer les boutons en javascript
	// $_SESSION['i'] = 0; // compteur pour la desactivation des boutons
	// declaration des differents lots d'equipes dans des tableaux
		$lot0 = ['Brésil','Argentine'];
		$lot1 = ['France','Italie'];
		$lot2 = ['Espagne','Allemagne'];
		$lot3 = ['Portugal','Haïti'];
	$trca = 'truncate classementa';
	$trcb = 'truncate classementb';
	mysqli_query($conn, $trca);
	mysqli_query($conn, $trcb);

	$trcm = 'truncate matchs';
	mysqli_query($conn, $trcm);

	$trcm = 'truncate groupea';
	mysqli_query($conn, $trcm);

	$trcm = 'truncate groupeb';
	mysqli_query($conn, $trcm);

	$trcm = 'truncate finaliste';
	mysqli_query($conn, $trcm);

	$trcm = 'truncate pfinal';
	mysqli_query($conn, $trcm);

	// creation d'une fonction nommee 'randomKey' qui permettra de generer
		// des cles aleatoires pour les choix d'equipes
		function randomKey()
		{
			global $key0,$key1,$key2,$key3,$lot0,$lot1,$lot2,$lot3;
			$key0 = array_rand($lot0);
			$key1 = array_rand($lot1);
			$key2 = array_rand($lot2);
			$key3 = array_rand($lot3);
		}

		// creation d'une variable qui indique que le tirage a deja ete fait 

		$_SESSION['done'] = true;	

		randomKey();
		$groupeA = [$lot0[$key0],$lot1[$key1],$lot2[$key2],$lot3[$key3]];

		for ($i=0; $i <4 ; $i++) { 
			
			$_SESSION['groupeA'][$i] = new Equipe($groupeA[$i], 0, 0, 0, 0, 0, 0, 0, 0);
			$insert = "INSERT INTO classementa VALUES (null, '$groupeA[$i]', 0, 0, 0, 0, 0, 0, 0, 0)";
			mysqli_query($conn, $insert); 
			$insert = "INSERT INTO groupea VALUES (null, '$groupeA[$i]')";
			mysqli_query($conn, $insert);
		}

		############### creation d'une boucle pour eviter d'avoir les meme equipes
		############### dans les deux groupes


		do{
			randomKey();
		
			if(strcasecmp($lot0[$key0], $groupeA[0])!=0){
				$_SESSION['groupeB'][0] = new Equipe($lot0[$key0], 0, 0, 0, 0, 0, 0, 0, 0);
				$insert = "INSERT INTO classementb VALUES (null, '$lot0[$key0]', 0, 0, 0, 0, 0, 0, 0, 0)";
				mysqli_query($conn, $insert);
				$insert = "INSERT INTO groupeb VALUES (null, '$lot0[$key0]')";
				mysqli_query($conn, $insert);
				break;
			}
		}while (strcasecmp($lot0[$key0], $groupeA[0])==0 );

		do{
			randomKey();
		
			if(strcasecmp($lot1[$key1], $groupeA[1])!=0){
				$_SESSION['groupeB'][1] = new Equipe($lot1[$key1], 0, 0, 0, 0, 0, 0, 0, 0);
				$insert = "INSERT INTO classementb VALUES (null, '$lot1[$key1]', 0, 0, 0, 0, 0, 0, 0, 0)";
				mysqli_query($conn, $insert);
				$insert = "INSERT INTO groupeb VALUES (null, '$lot1[$key1]')";
				mysqli_query($conn, $insert);
				break;
			}
		}while (strcasecmp($lot1[$key1], $groupeA[1])==0 );

		do{
			randomKey();
		
			if(strcasecmp($lot2[$key2], $groupeA[2])!=0){
				$_SESSION['groupeB'][2] = new Equipe($lot2[$key2], 0, 0, 0, 0, 0, 0, 0, 0);
				$insert = "INSERT INTO classementb VALUES (null, '$lot2[$key2]', 0, 0, 0, 0, 0, 0, 0, 0)";
				mysqli_query($conn, $insert);
				$insert = "INSERT INTO groupeb VALUES (null, '$lot2[$key2]')";
				mysqli_query($conn, $insert);			
				break;
			}
		}while (strcasecmp($lot2[$key2], $groupeA[2])==0 );

		do{
			randomKey();
		
			if(strcasecmp($lot3[$key3], $groupeA[3])!=0){
				$_SESSION['groupeB'][3] = new Equipe($lot3[$key3], 0, 0, 0, 0, 0, 0, 0, 0);
				$insert = "INSERT INTO classementb VALUES (null, '$lot3[$key3]', 0, 0, 0, 0, 0, 0, 0, 0)";
				mysqli_query($conn, $insert);
				$insert = "INSERT INTO groupeb VALUES (null, '$lot3[$key3]')";
				mysqli_query($conn, $insert);
				break;
			}
		}while (strcasecmp($lot3[$key3], $groupeA[3])==0 );

 		header('location:.././index.php');
		 
?>
<?php
	session_start();
	if (isset($_SESSION['signin-error']) && !empty($_SESSION['signin-error'])) {
		echo "<div class='error-message'>".$_SESSION['signin-error']."</div>";
		$_SESSION['signin-error'] = "";
	}

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sign in | </title>
	<link rel="stylesheet" type="text/css" href=".././css/login.css">
</head>
<body>

	<div class="login">
            <div class="login-screen">
                <div class="app-title">
                    <h1>Sign In</h1>
                </div>
     <form class="login-form" method="post" action="signin_process.php" autocomplete="off">
                    <div class="control-group">
                        <input type="text" name="uname" placeholder="username" required class="input">
                    </div>

                    <div class="control-group">
                        <input type="password" name="passwd" placeholder="password" required class="input" id="pass">
                    </div>

                    <div class="control-group">
                        <input type="password" name="passwdC" placeholder="confirm password" required class="input" id="passC">
                    </div>

                    <button type="submit" class="btn" name="signin">SIGN IN</button>
                    <!-- <button type="reset">Effacer</button> -->

                </form>
                <div><a href="../login.php" class="signinlink">Log in</a></div>
            </div>
        </div>
	

	

</body>
</html>
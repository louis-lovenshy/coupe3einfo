-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2021 at 01:33 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foot`
--
CREATE DATABASE IF NOT EXISTS `foot` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `foot`;

-- --------------------------------------------------------

--
-- Table structure for table `classementa`
--

CREATE TABLE `classementa` (
  `id` int(11) NOT NULL,
  `equipe` varchar(255) COLLATE latin1_bin NOT NULL,
  `mj` int(11) NOT NULL,
  `mg` int(11) NOT NULL,
  `mn` int(11) NOT NULL,
  `mp` int(11) NOT NULL,
  `bp` int(11) NOT NULL,
  `bc` int(11) NOT NULL,
  `diff` int(11) NOT NULL,
  `pt` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- --------------------------------------------------------

--
-- Table structure for table `classementb`
--

CREATE TABLE `classementb` (
  `id` int(11) NOT NULL,
  `equipe` varchar(255) COLLATE latin1_bin NOT NULL,
  `mj` int(11) NOT NULL,
  `mg` int(11) NOT NULL,
  `mn` int(11) NOT NULL,
  `mp` int(11) NOT NULL,
  `bp` int(11) NOT NULL,
  `bc` int(11) NOT NULL,
  `diff` int(11) NOT NULL,
  `pt` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- --------------------------------------------------------

--
-- Table structure for table `finaliste`
--

CREATE TABLE `finaliste` (
  `id` int(11) NOT NULL,
  `equipe` varchar(255) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- --------------------------------------------------------

--
-- Table structure for table `groupea`
--

CREATE TABLE `groupea` (
  `id` int(11) NOT NULL,
  `equipe` varchar(255) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- --------------------------------------------------------

--
-- Table structure for table `groupeb`
--

CREATE TABLE `groupeb` (
  `id` int(11) NOT NULL,
  `equipe` varchar(255) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- --------------------------------------------------------

--
-- Table structure for table `matchs`
--

CREATE TABLE `matchs` (
  `id` int(11) NOT NULL,
  `equipe1` varchar(255) COLLATE latin1_bin NOT NULL,
  `score1` int(11) NOT NULL,
  `equipe2` varchar(255) COLLATE latin1_bin NOT NULL,
  `score2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- --------------------------------------------------------

--
-- Table structure for table `pfinal`
--

CREATE TABLE `pfinal` (
  `id` int(11) NOT NULL,
  `equipe` varchar(255) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classementa`
--
ALTER TABLE `classementa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classementb`
--
ALTER TABLE `classementb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `finaliste`
--
ALTER TABLE `finaliste`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupea`
--
ALTER TABLE `groupea`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupeb`
--
ALTER TABLE `groupeb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `matchs`
--
ALTER TABLE `matchs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pfinal`
--
ALTER TABLE `pfinal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classementa`
--
ALTER TABLE `classementa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `classementb`
--
ALTER TABLE `classementb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `finaliste`
--
ALTER TABLE `finaliste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groupea`
--
ALTER TABLE `groupea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groupeb`
--
ALTER TABLE `groupeb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `matchs`
--
ALTER TABLE `matchs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pfinal`
--
ALTER TABLE `pfinal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
